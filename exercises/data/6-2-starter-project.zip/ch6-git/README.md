# Corn yields and irrigation

Corn yields of irrigated and non-irrigated fields in Nebraska counties, 2008.
