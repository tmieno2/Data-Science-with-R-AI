setwd("C:/Users/jan/Desktop/corn")
library(tidyverse)

corn <- filter(corn, Yield > 120)
model <- lm(Yield ~ Irrigated, data = corn)
summary(model)
write_csv(corn, "corn_yields.csv")
