setwd("C:/Users/jan/Desktop/corn")
library(tidyverse)

corn <- read_csv("corn_yields_fixed.csv")
corn <- select(corn, FIPS, County_name, Irrigated, Yield)
write_csv(corn, "corn_clean.csv")

corn %>% group_by(Irrigated) %>% summarise(mean_yield = mean(Yield))

ggplot(corn, aes(x = factor(Irrigated), y = Yield)) + geom_boxplot()
ggsave("yield_by_irrigation.png")
